package parte1;

public class AlunoVip extends Aluno{
	public AlunoVip(String nome, int numeroCadastro) {
        super(nome, numeroCadastro);
        
    }
}
